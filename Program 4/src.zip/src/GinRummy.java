import java.awt.BorderLayout;
import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;

class GinRummy {
	
	public GinRummy() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		JFrame frame = new JFrame("Card Table");
		Container display = frame.getContentPane();
		CardPicker picker = new CardPicker();
		Deck deck = new Deck();
		deck.shuffle();
		Hand hand = new Hand();
		// hard coded test for 7 cards in the initial hand
		for(int i = 0; i < 7; i++) {
			hand.add(deck.draw());
		}
		HandDisplay handDisplay = new HandDisplay(hand, picker);
		display.add(handDisplay);
				
		JButton gin = new JButton("Gin");
		JButton draw = new JButton("Draw");
		JButton flip = new JButton("Flip");
		
		display.add(BorderLayout.NORTH, draw);
		display.add(BorderLayout.SOUTH, gin);
		
		HandController controller = new HandController(handDisplay, deck);
		gin.addActionListener(controller);
		draw.addActionListener(controller);
		flip.addActionListener(controller);
		
		frame.pack();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}